# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import test_program_without_code_operations
from . import test_program_with_code_operations
from . import test_program_rules
from . import test_program_numbers

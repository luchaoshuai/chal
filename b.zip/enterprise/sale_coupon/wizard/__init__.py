# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import sale_coupon_apply_code
from . import sale_coupon_generate

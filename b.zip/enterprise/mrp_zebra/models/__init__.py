# -*- coding: utf-8 -*-models

from . import mrp_workorder
from . import quality_point

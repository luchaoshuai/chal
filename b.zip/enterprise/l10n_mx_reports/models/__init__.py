# coding: utf-8
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import trial_balance
from . import coa
from . import account_diot
from . import res_partner
from . import res_country

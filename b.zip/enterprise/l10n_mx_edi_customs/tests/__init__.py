# coding: utf-8

from . import test_l10n_mx_invoice_customs

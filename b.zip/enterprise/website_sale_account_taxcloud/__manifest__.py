# -*- coding: utf-8 -*-
{
    'name': "Account TaxCloud - Ecommerce",
    'summary': """""",
    'description': """
    """,
    'category': 'Accounting',
    'depends': ['account_taxcloud', 'website_sale'],
    'auto_install': True,
    'license': 'OEEL-1',
}

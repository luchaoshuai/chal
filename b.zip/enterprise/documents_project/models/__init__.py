# -*- coding: utf-8 -*-

from . import documents
from . import res_config_settings
from . import workflow
from . import res_company

# -*- coding: utf-8 -*-

from . import res_config_settings
from . import account_invoice
from . import product
from . import res_partner
from . import res_company
from . import res_city
from . import res_locality

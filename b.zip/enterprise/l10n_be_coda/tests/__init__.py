# -*- encoding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

# Copyright (c) 2012 Noviat nv/sa (www.noviat.be). All rights reserved.

# If someone reads this, please ask to the accounting team to fix me
# I'm commented since the 9th version... I want to be executed. Please.
# import test_import_bank_statement